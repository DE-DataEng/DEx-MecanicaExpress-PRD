# Mecânica Express 2.0 — pacote de produção

## Conteúdo
- `assets/logo/mecanica_express_badge.svg`: logo circular principal
- `assets/logo/mecanica_express_flat.svg`: logo horizontal flat
- `src/login_screen.py`: tela de login completa em Flet
- `src/app.py`: sistema inicial com dashboard e identidade visual
- `src/theme.py`: tema central do projeto

## Como executar
1. Instale o Flet 0.28.3
2. Copie a pasta `assets` para dentro de `src`, ou ajuste o `assets_dir`
3. Execute:

```bash
python app.py
```

## Observação
Os SVGs foram recriados em versão limpa para produção, mantendo o conceito visual da marca.
